for var in range(5, 1000000):
	if var % 5 ==0:
		print var