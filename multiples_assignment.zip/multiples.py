for var in range(1, 1000):
	if var % 2 == 1:
		print var